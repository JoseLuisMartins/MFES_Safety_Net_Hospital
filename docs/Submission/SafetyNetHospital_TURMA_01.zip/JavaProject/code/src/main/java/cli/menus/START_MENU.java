package cli.menus;


public enum START_MENU {
    HOSPITALS,
    DOCTORS,
    PATIENTS,
    APPOINTMENTS,
    EXIT,
}
