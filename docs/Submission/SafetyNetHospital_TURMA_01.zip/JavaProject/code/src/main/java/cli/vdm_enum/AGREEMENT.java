package cli.vdm_enum;

/**
 * Created by josemartins on 24-12-2017.
 */
public enum AGREEMENT {
    ADSE,
    MEDICARE,
    MEDIS,
    MULTICARE,
    NONE,
}
