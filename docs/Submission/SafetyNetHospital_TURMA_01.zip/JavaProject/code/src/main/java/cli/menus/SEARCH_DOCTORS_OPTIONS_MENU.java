package cli.menus;

/**
 * Created by josemartins on 24-12-2017.
 */
public enum SEARCH_DOCTORS_OPTIONS_MENU {
    SEE_ALL,
    BY_SPECIALTY,
    BACK,
    EXIT
}
