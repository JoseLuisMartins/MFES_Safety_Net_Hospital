package cli.menus;

/**
 * Created by josemartins on 24-12-2017.
 */
public enum HOSPITAL_MENU {
    ADD,
    REMOVE,
    SEARCH,
    ASSOCIATE_DOCTOR,
    DISASSOCIATE_DOCTOR,
    ADD_AGREEMENT,
    REMOVE_AGREEMENT,
    BACK,
    EXIT,
}
