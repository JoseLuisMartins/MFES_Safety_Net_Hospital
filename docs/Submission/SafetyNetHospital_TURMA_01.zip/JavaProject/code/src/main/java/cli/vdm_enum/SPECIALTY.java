package cli.vdm_enum;

/**
 * Created by josemartins on 24-12-2017.
 */
public enum SPECIALTY {
    ORTOPEDIA,
    CARDIOLOGIA,
    OFTALMOLOGIA,
    DERMATOLOGIA,
    GINECOLOGIA,
    NEUROLOGIA,
    PEDIATRIA,
    REUMATOLOGIA,
    UROLOGIA,
    PNEUMOLOGIA,
}
