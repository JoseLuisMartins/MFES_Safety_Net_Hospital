package cli.menus;

/**
 * Created by josemartins on 24-12-2017.
 */
public enum DOCTOR_MENU {
    ADD,
    REMOVE,
    SEARCH,
    BACK,
    EXIT,
}
