package cli.menus;


public enum SEARCH_HOSPITALS_OPTIONS_MENU {
    SEE_ALL,
    BY_NAME,
    BY_SPECIALTY,
    BY_AGREEMENT,
    BY_CITY,
    BACK,
    EXIT
}
