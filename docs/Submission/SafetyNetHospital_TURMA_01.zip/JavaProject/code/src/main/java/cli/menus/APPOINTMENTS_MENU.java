package cli.menus;

/**
 * Created by josemartins on 24-12-2017.
 */
public enum APPOINTMENTS_MENU {
    ADD,
    REMOVE,
    SEARCH,
    GET_FIRST_AVAILABLE_DATE_FOR_AN_APPOINTMENT,
    BACK,
    EXIT,
}
