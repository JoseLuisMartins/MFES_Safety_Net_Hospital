package cli.menus;

public enum PATIENTS_MENU {
    ADD,
    REMOVE,
    ADD_CLINICAL_OBSERVATION_TO_PATIENT,
    SEE_ALL,
    BACK,
    EXIT,
}
