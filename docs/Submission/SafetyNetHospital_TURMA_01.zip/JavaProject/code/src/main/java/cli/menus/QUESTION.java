package cli.menus;

public enum QUESTION {
    YES,
    NO
}
